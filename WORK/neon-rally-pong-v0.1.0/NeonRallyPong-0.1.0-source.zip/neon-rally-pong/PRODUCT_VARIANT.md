# Neon Rally variation

This product was created from the `godot-headless` Pong scaffold and then
customized in the disposable Arena workspace before in-engine confirmation.

- Game title: **Neon Rally Pong**
- Theme: violet court, mint player paddle, magenta computer paddle, neon ball
- Gameplay: faster serves, faster player response, rising rally speed, and a
  slightly more forgiving computer opponent
- Target configuration: Windows 10/11 x86_64 and Android 9+ / API 28

The source remains self-contained and is verified by the included headless
GDScript confirmation.
